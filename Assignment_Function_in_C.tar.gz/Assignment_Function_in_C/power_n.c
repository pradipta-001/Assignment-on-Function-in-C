#include <stdio.h>

long power(int x,int n){
	long res=1;
	while(n--){
		res=res*x;
	}
	return res;
}

int main(){
	int x,n;
	printf("Enetr value of x and n: ");
	scanf("%d %d",&x, &n);
	long res= power(x,n);

	printf("res= %ld\n",res);

	return 0;
}
