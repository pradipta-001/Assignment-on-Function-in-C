#include <stdio.h>

long sum(int n){
    if(n==0)return 0;
    
	long res=0;
	
	res += (n*n) + sum(n-1);
	return res;
}

int main(){
	int x,n;
	printf("Enetr value of n: ");
	scanf("%d", &n);
	long res= sum(n);

	printf("res= %ld\n",res);

	return 0;
}
